﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using System.Windows.Media;
using Microsoft.Xna.Framework.Media;
using System.IO;
using System.Data;
using System.Windows.Media.Imaging;
using System.IO.IsolatedStorage;

using Windows.Storage;
using Microsoft.Phone.Tasks;
using Windows.ApplicationModel.DataTransfer;
using Windows.Foundation;
using Windows.Storage.Streams;
using Windows.Graphics.Imaging;
using Windows.System;

namespace PerfectCamera
{
    public partial class Download : PhoneApplicationPage
    {
        public static StorageFolder CameraRoll { get; }
        WriteableBitmap wbmp;
        WriteableBitmap xx1;
        string txt = "";
        WriteableBitmap wb;
        private const String FileNamePrefix = "mscam";
       
        public Download()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/CameraPage.xaml", UriKind.Relative));
        }
        private void About_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/AboutPage.xaml", UriKind.Relative));
        }
        private void Tutorial_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/Tutorial.xaml", UriKind.Relative));
        }
        private void btnshare_Click(object sender, EventArgs e)

        {

           
            /*PhotoChooserTask photochooserTask = new PhotoChooserTask();
            photochooserTask.Completed += photoChooserTask_Completed;
            photochooserTask.Show();*/

            try
            {
                
                using (MediaLibrary mb = new MediaLibrary())
                {
                    int cnt = mb.Pictures.Count - 1;
                    String name = mb.Pictures[cnt].Name;
                    String path = "C:\\Data\\Users\\Public\\Pictures\\Camera Roll\\"+ name;
                    ShowShareMediaTask(path);
                }

            }
            catch (Exception)
            {

                throw;
            }

        }
      
        void ShowShareMediaTask(string path)
        {
            ShareMediaTask shareMediaTask = new ShareMediaTask();
            shareMediaTask.FilePath = path;
            shareMediaTask.Show();
        }
        void photoChooserTask_Completed(object sender, PhotoResult e)
        {
            PhotoChooserTask photoChooserTask;
            photoChooserTask = new PhotoChooserTask();
            photoChooserTask.Completed += new EventHandler<PhotoResult>(photoChooserTask_Completed);
            photoChooserTask.Show();

            if (e.TaskResult == TaskResult.OK)
            {
                String path = e.OriginalFileName;

                ShowShareMediaTask(e.OriginalFileName);
            }

        }



        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            //Thread.Sleep(5000);
            LoadImg();

        }
        
        protected void LoadImg()
        {
            try
            {
                BitmapImage bmp = new BitmapImage();
                using (MediaLibrary mb = new MediaLibrary())
                {
                    int cnt = mb.Pictures.Count - 1;
                   
                    Stream img = mb.Pictures[cnt].GetImage();
                   
                 
                    bmp.SetSource(img);
                   
                    wbmp = new WriteableBitmap(bmp);
                    if (PerfectCamera.DataContext.Instance.Filterenum == FilterUsed.Excel)
                    {
                        fn_ExcelColor(wbmp);
                       
                    }
                    else
                    {
                        top1.Fill = new SolidColorBrush(Color.FromArgb(Convert.ToByte(255), Convert.ToByte(45), Convert.ToByte(89), Convert.ToByte(154)));
                        fbar.Visibility = Visibility.Collapsed;
                        icol.Visibility = Visibility.Collapsed;
                        irow.Visibility = Visibility.Collapsed;
                        fn_camera1(wbmp);
                        
                    }

                   
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        private void fn_ExcelColor(WriteableBitmap wmb)
        {
            try
            {

                System.Windows.Media.Color clr;
                int w1;
                int h1;
                if (wmb.PixelWidth > 1000 || wmb.PixelHeight > 1000)
                {
                    w1 = wmb.PixelWidth/30;
                    h1 = wmb.PixelHeight/30;
                }
                else
                {
                    w1 = wmb.PixelWidth / 5;
                    h1 = wmb.PixelHeight / 5;
                }

                MemoryStream ms = new MemoryStream();
                wmb.SaveJpeg(ms, w1, h1, 0, 100);
                BitmapImage imgbt = new BitmapImage();
                imgbt.SetSource(ms);
                WriteableBitmap swb = new WriteableBitmap(imgbt);

                xx1 = new WriteableBitmap(swb.PixelWidth * 10, swb.PixelHeight * 10);

                int[] srcpic = swb.Pixels;
                txt = "";


                for (int a = 0; a < srcpic.Length; a++)
                {
                    int row = a / w1;
                    int col = a % w1;


                    for (int k = 0; k < 10; k++)
                    {
                        for (int l = 0; l < 10; l++)
                        {
                            int p1 = swb.Pixels[a];
                            byte[] b1 = BitConverter.GetBytes(p1);
                            extension.SetPixel(xx1, (row * 10) + k, (col * 10) + l, b1[3], b1[2], b1[1], b1[0]);
                        }
                    }

                }

                //wb = new WriteableBitmap((BitmapSource)myimage.Source);

                txtHtml.Visibility = Visibility.Collapsed;
                MainImage.Visibility = Visibility.Visible;
                MainImage.Source = xx1;
                fn_filesave(xx1);
                MainImage.Stretch = Stretch.UniformToFill;

                //MainImage.Width = 600;
                //MainImage.Height = 520;

                /*wb.Render(myimage, null);
                finimg.Source = wb;
                wb.Invalidate();
                */

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void fn_camera1(WriteableBitmap wmb)
        {
            try
            {
                int w1;
                int h1;
                if (wmb.PixelWidth > 1000 || wmb.PixelHeight > 1000)
                {
                    w1 = wmb.PixelWidth / 10;
                    h1 = wmb.PixelHeight / 20;
                }
                else
                {
                    w1 = wmb.PixelWidth / 5;
                    h1 = wmb.PixelHeight / 5;
                }

                MemoryStream ms = new MemoryStream();
                wmb.SaveJpeg(ms, w1, h1, 0, 100);
                BitmapImage imgbt = new BitmapImage();
                imgbt.SetSource(ms);
                WriteableBitmap swb = new WriteableBitmap(imgbt);
                int[] srcpic = swb.Pixels;
                txt = "";
                string characters = " .,:;i1tfLCG08@";

                for (int a = 0; a < srcpic.Length; a++)
                {
                    int pixel = swb.Pixels[a];

                    int row = a / w1;
                    int col = a % w1;

                    byte[] bytes = BitConverter.GetBytes(pixel);

                    Color clr = Color.FromArgb(255, bytes[0], bytes[1], bytes[2]);
                    double cred = Math.Floor((bytes[0] - 128) * 1.3681) + 128;
                    double cgre = Math.Floor((bytes[1] - 128) * 1.3681) + 128;
                    double cblu = Math.Floor((bytes[2] - 128) * 1.3681) + 128;
                    double calp = bytes[3];

                    double bright = (0.299 * cred + 0.587 * cgre + 0.114 * cblu) / 255;

                    double ret = (14) - Math.Round(bright * 14);
                    if (ret > 13)
                    {
                        ret = 13;
                    }
                    if (ret < 0)
                    {
                        ret = 0;
                    }
                    txt += characters.Substring(Convert.ToInt32(ret), 1);
                    if (a > 0 && a % w1 == 0)
                    {
                        txt += System.Environment.NewLine;
                    }
                }

                MainImage.Visibility = Visibility.Collapsed;
                txtHtml.Visibility = Visibility.Visible;
              //  wb = new WriteableBitmap((BitmapSource)myimage.Source);
                txtHtml.Text = txt;
                txtHtml.FontSize = 2.8;
                txtHtml.Foreground = new SolidColorBrush(Colors.Black);
                txtHtml.FontFamily = new System.Windows.Media.FontFamily("Lucida Console");
                txtHtml.FontWeight = FontWeights.ExtraBold;
                double f = (((640 / txtHtml.ActualHeight) * 3) + ((480 / txtHtml.ActualWidth) * 3)) / 2;
                txtHtml.FontSize = f;
                /*wb.Render(tb, null);
                finimg.Source = wb;
                wb.Invalidate();
               */
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void fn_filesave(WriteableBitmap sourcewb)
        {
            try
            {
                WriteableBitmap savewb = new WriteableBitmap(sourcewb);

                using (var medialibry = new MediaLibrary())
                {

                    using (MemoryStream ms = new MemoryStream())
                    {
                        sourcewb.SaveJpeg(ms, sourcewb.PixelWidth, sourcewb.PixelHeight, 0, 100);
                        ms.Seek(0, SeekOrigin.Begin);
                        String a = DateTime.Now.ToString("yyyyMMddHHmmss");
                        
                        medialibry.SavePictureToCameraRoll(FileNamePrefix+a+
                            ".jpg", ms);
                        var bmp = new WriteableBitmap(savewb);

                        using (IsolatedStorageFile storage = IsolatedStorageFile.GetUserStoreForApplication())
                        {
                            if (storage.FileExists("tester.doc"))
                            {
                                storage.DeleteFile("tester.doc");
                            }
                            using (IsolatedStorageFileStream stream = storage.CreateFile("tester.doc"))

                            {

                                bmp.SaveJpeg(stream, 200, 100, 0, 95);
                                stream.Close();
                            }
                            if (storage.FileExists("tester.doc"))
                            {
                                storage.DeleteFile("tester.doc");
                            }
                            StorageFolder local = Windows.Storage.ApplicationData.Current.LocalFolder;

                        }
                    }
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        protected async void tglbtn_Click(object sender, EventArgs e)
        {
            try
            {
                StorageFolder local = Windows.Storage.ApplicationData.Current.LocalFolder;
                StorageFile file = await local.GetFileAsync("Mscam.docx");
                await Launcher.LaunchFileAsync(file);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
        }