﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using System.Threading;


namespace PerfectCamera
{
    public partial class Tutorial : PhoneApplicationPage
    {
        public Tutorial()
        {
            Thread.Sleep(1000);
            InitializeComponent();
            
        }
        private void BtnCam_Click(object sender, RoutedEventArgs e)
        {
            PerfectCamera.DataContext.Instance.CameraType = PerfectCameraType.Selfie;
            NavigationService.Navigate(new Uri("/Tutorialsecond.xaml", UriKind.Relative));
        }
    }
}