﻿using System;
using System.Windows;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using System.Text;
using Microsoft.Phone.Tasks;
using System.IO;
using System.IO.IsolatedStorage;
using Microsoft.Xna.Framework.Media;
using Windows.Storage;
using Windows.System;
using Microsoft.Xna.Framework.Media.PhoneExtensions;

namespace PerfectCamera
{
    public partial class test : PhoneApplicationPage
    {
        WriteableBitmap wb;
        //Boolean isTaskLaunched;
        Boolean istglchecked;
        PhotoChooserTask PhotoChooserTask;
        private bool isTaskLaunched;
        string txt = "";
        StringBuilder sb = new StringBuilder();
        Boolean isTglChecked;
        Boolean FileChoosed;
        WriteableBitmap wbmp;
        WriteableBitmap xx1;
        String path;
        public test()
        {
            InitializeComponent();
            isTglChecked = true;
            this.PhotoChooserTask = new PhotoChooserTask();
            this.PhotoChooserTask.Completed += new EventHandler<PhotoResult>(photocoosertask_completed);
            isTaskLaunched = false;

        }
        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            //Thread.Sleep(5000);
            proceed();

        }
        private void proceed()
        {

            if (!isTaskLaunched)
            {
                this.PhotoChooserTask = new PhotoChooserTask();
                this.PhotoChooserTask.Completed += new EventHandler<PhotoResult>(photocoosertask_completed);
                isTaskLaunched = true;
                PhotoChooserTask.Show();
                PhotoChooserTask.Show();
            }

        }
        private void About_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/AboutPage.xaml", UriKind.Relative));
        }
        private void Tutorial_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/Tutorial.xaml", UriKind.Relative));
        }

        public void photocoosertask_completed(object sender, PhotoResult e)
        {
            try
            {
                if (e.TaskResult == TaskResult.OK)
                {
                    path = e.OriginalFileName;
                    FileChoosed = true;
                    BitmapImage bmp = new BitmapImage();
                    bmp.SetSource(e.ChosenPhoto);
                    wbmp = new WriteableBitmap(bmp);

                    if (isTglChecked == true)
                    {
                        fn_ExcelColor(wbmp);
                    }
                    else
                    {
                        fn_camera1(wbmp);

                    }
                }
                else if (e.TaskResult == TaskResult.None || e.TaskResult == TaskResult.Cancel)
                {
                    FileChoosed = false;

                    this.Dispatcher.BeginInvoke(delegate()
                    {
                    });

                }

                MainImage.Visibility = Visibility.Visible;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        private void btnshares_Click(object sender, EventArgs e)

        {

            try
            {

                using (MediaLibrary mb = new MediaLibrary())
                {
                    
                    ShowShareMediaTask(path);
                }

            }
            catch (Exception)
            {

                throw;
            }

        }
        void ShowShareMediaTask(string path)
        {
            ShareMediaTask shareMediaTask = new ShareMediaTask();
            shareMediaTask.FilePath = path;
            shareMediaTask.Show();
        }
        protected async void tglbtns_Click(object sender, EventArgs e)
        {
            var bmp = new WriteableBitmap(LayoutRoot, new TranslateTransform());
            var width = (int)bmp.PixelWidth;
            var height = (int)bmp.PixelHeight;
            bmp.Render(LayoutRoot, new TranslateTransform());
            using (var ms = new MemoryStream())
            {
                bmp.SaveJpeg(ms, width, height, 0, 100);
                ms.Seek(0, System.IO.SeekOrigin.Begin);
                var lib = new MediaLibrary();
                var dateStr = DateTime.Now.Ticks;
                var picture = lib.SavePicture(string.Format("screenshot" + dateStr + ".jpg"), ms);
                var task = new ShareMediaTask();
                task.FilePath = picture.GetPath();
                task.Show();
            }

        }
        private void fn_filesave(WriteableBitmap sourcewb)
        {
            try
            {
                WriteableBitmap savewb = new WriteableBitmap(sourcewb);
                using (var isolatedstorage = IsolatedStorageFile.GetUserStoreForApplication())
                {
                    if (isolatedstorage.FileExists("test.jpg"))
                    {
                        isolatedstorage.DeleteFile("test.jpg");

                    }
                }
                using(var medialibry=new MediaLibrary())
                {
                    using(MemoryStream ms=new MemoryStream())
                    {
                        sourcewb.SaveJpeg(ms, sourcewb.PixelWidth, sourcewb.PixelHeight, 0, 100);
                        ms.Seek(0, SeekOrigin.Begin);
                        var picture = medialibry.SavePicture("test.jpg", ms);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private void btnbacks_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/CameraPage.xaml", UriKind.Relative));
        }
        private void fn_camera1(WriteableBitmap wmb)
        {
            try
            {
                int w1;
                int h1;
                if (wmb.PixelWidth > 1000 || wmb.PixelHeight > 1000)
                {
                    w1 = wmb.PixelWidth / 10;
                    h1 = wmb.PixelHeight / 20;
                }
                else
                {
                    w1 = wmb.PixelWidth / 5;
                    h1 = wmb.PixelHeight / 5;
                }

                MemoryStream ms = new MemoryStream();
                wmb.SaveJpeg(ms, w1, h1, 0, 100);
                BitmapImage imgbt = new BitmapImage();
                imgbt.SetSource(ms);
                WriteableBitmap swb = new WriteableBitmap(imgbt);
                int[] srcpic = swb.Pixels;
                txt = "";
                string characters = " .,:;i1tfLCG08@";

                for (int a = 0; a < srcpic.Length; a++)
                {
                    int pixel = swb.Pixels[a];

                    int row = a / w1;
                    int col = a % w1;

                    byte[] bytes = BitConverter.GetBytes(pixel);

                    Color clr = Color.FromArgb(255, bytes[0], bytes[1], bytes[2]);
                    double cred = Math.Floor((bytes[0] - 128) * 1.3681) + 128;
                    double cgre = Math.Floor((bytes[1] - 128) * 1.3681) + 128;
                    double cblu = Math.Floor((bytes[2] - 128) * 1.3681) + 128;
                    double calp = bytes[3];

                    double bright = (0.299 * cred + 0.587 * cgre + 0.114 * cblu) / 255;

                    double ret = (14) - Math.Round(bright * 14);
                    if (ret > 13)
                    {
                        ret = 13;
                    }
                    if (ret < 0)
                    {
                        ret = 0;
                    }
                    txt += characters.Substring(Convert.ToInt32(ret), 1);
                    if (a > 0 && a % w1 == 0)
                    {
                        txt += System.Environment.NewLine;
                    }
                }

                MainImage.Visibility = Visibility.Collapsed;
                txtHtml.Visibility = Visibility.Visible;
                wb = new WriteableBitmap((BitmapSource)myimage.Source);
                txtHtml.Text = txt;
                txtHtml.FontSize = 2.8;
                txtHtml.Foreground = new SolidColorBrush(Colors.Black);
                txtHtml.FontFamily = new System.Windows.Media.FontFamily("Lucida Console");
                txtHtml.FontWeight = FontWeights.ExtraBold;
                double f = (((640 / txtHtml.ActualHeight) * 3) + ((480 / txtHtml.ActualWidth) * 3)) / 2;
                txtHtml.FontSize = f;
                /*wb.Render(tb, null);
                MainImage.Source = wb;
                wb.Invalidate();
               */
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        protected void LoadImg()
        {
            try
            {
                BitmapImage bmp = new BitmapImage();
                using (MediaLibrary mb = new MediaLibrary())
                {
                    int cnt = mb.Pictures.Count - 1;

                    Stream img = mb.Pictures[cnt].GetImage();

                    bmp.SetSource(img);
                }
                    wbmp = new WriteableBitmap(bmp);

                if (isTglChecked == true)
                {
                    fn_ExcelColor(wbmp);
                }
                else
                {
                    fn_camera1(wbmp);

                }
               
               

            }
            catch (Exception)
            {

                throw;
            }
        }


        private void fn_ExcelColor(WriteableBitmap wmb)
        {
            try
            {

                Color clr;
                int w1;
                int h1;
                if (wmb.PixelWidth > 1000 || wmb.PixelHeight > 1000)
                {
                    w1 = wmb.PixelWidth / 30;
                    h1 = wmb.PixelHeight / 30;
                }
                else
                {
                    w1 = wmb.PixelWidth / 5;
                    h1 = wmb.PixelHeight / 5;
                }

                MemoryStream ms = new MemoryStream();
                wmb.SaveJpeg(ms, w1, h1, 0, 100);
                BitmapImage imgbt = new BitmapImage();
                imgbt.SetSource(ms);
                WriteableBitmap swb = new WriteableBitmap(imgbt);

                xx1 = new WriteableBitmap(swb.PixelWidth * 10, swb.PixelHeight * 10);

                int[] srcpic = swb.Pixels;
                txt = "";


                for (int a = 0; a < srcpic.Length; a++)
                {
                    int row = a / w1;
                    int col = a % w1;

                    
                    for (int k = 0; k < 10; k++)
                    {
                        for (int l = 0; l < 10; l++)
                        {
                            int p1 = swb.Pixels[a];
                            byte[] b1 = BitConverter.GetBytes(p1);
                            extension.SetPixel(xx1, (row * 10) + k, (col * 10) + l, b1[3], b1[2], b1[1], b1[0]);
                        }
                    }

                }

                //wb = new WriteableBitmap((BitmapSource)myimage.Source);

                txtHtml.Visibility = Visibility.Collapsed;
                MainImage.Visibility = Visibility.Visible;
                MainImage.Source = xx1;
                MainImage.Stretch = Stretch.UniformToFill;

                //MainImage.Width = 600;
                //MainImage.Height = 520;

                /*wb.Render(myimage, null);
                MainImage.Source = wb;
                wb.Invalidate();
                */

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


    }
}